The EasyStar model is from http://gitorious.org/ron-s-hanger/easystar-rc (fork at https://gitorious.org/~thomasgubler/ron-s-hanger/thomasgublers-easystar-rc)

I slightly adapted some files in order to make the model work when it's not located in the default flightgear aircraft folder.

-Thomas Gubler
